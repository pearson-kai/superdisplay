# superdisplay

## General Information:
Author: Kai Pearson  
Date: Mar 19th, 2026  
Email: kaipearson@dal.ca  

## Import Information:

To meshes into the world, use the command `import` command. `import` can be used on individual .txt files or on folders full of meshes.  

For instance, `import ./meshfolder/` will import all meshes in `meshfolder`, while `import ./meshfolder/cube.obj` will import only the `cube.obj` file.

Please note that the directory starts from wherever the `superdisplay.exe` file is located.

## The .obj File Type

.obj is a file type made by Wavefront, and is the primary exported file type for 3D rendering software (such as Blender).

superdisplay supports the .obj file type and can render most imported .obj files, but it's important to recognize that only certain prefixes are recognized.

### Supported Prefixes
- v x y z (defines a vertex at point (x,y,z))
- f a b c (defines the face of a triangle with indexed vertices)
- o name (defines a name for the mesh)

### Unsupported Prefixes
- vt u v (texture coordinate)
- vn nx ny nz (normal coordinate)
- g name (group naming)
- s 1/0 (smoothing on or off)
- mtllib filelocation (using material files)
- usemtl material (using a temporary material)

What you might be able to recognize is that the majority of unsupported prefixes have to do with .mtl file types and lighting vectors. This is because superdisplay unfortunately does not support textures. Rather, each vertex is given a random colour and adjacent points are blended together. To create solid colours, triangles can be made with points containing the same colour. While this system falls short often, it can still be used effictively to create small models.  

A system to give individual points colours was recently removed, but a change to how objects and their colours are defined will be made in the near future.