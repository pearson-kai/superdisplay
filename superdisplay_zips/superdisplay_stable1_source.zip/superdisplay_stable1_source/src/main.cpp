#include <iostream>
#include <filesystem>
#include <algorithm>
#include <ctime>

#include "Mesh.hpp"
#include "World.hpp"
#include "Camera.hpp"
#include "Screen.hpp"

const int WIDTH = 800;
const int HEIGHT = 600;
const float FOV = 80.0f;
const int FPS_LIMIT = 144;
const int DELAY = (int) 1000.0f/FPS_LIMIT;

int main()
{
    srand(time(NULL));
	SDL_Init(SDL_INIT_VIDEO);

	Screen screen = Screen("superdisplay",WIDTH,HEIGHT);
	Mesh* myMesh = nullptr;

	World world = World();
    std::ifstream loadfrom("./settings/settings.txt");
    
    std::string line = "";
    std::getline(loadfrom,line);

    while(line != "end")
    {
        if(line.size() > 2 || (line.at(0) != '/' && line.at(1) != '/') )
        {
            if(line.substr(0,line.find(' ')) == "import")
            {
                fs::path entry = line.substr(line.find(' ') + 1,line.size());
                std::cout << "Found mesh: " << entry << std::endl;
                Mesh* mesh = Mesh::meshMaker(entry);
                if(mesh)
                {
                    mesh->setPos(1,-1);
                    myMesh = mesh;
                    world.add(true, mesh); 
                }
                else
                {
                    std::cout << "Mesh skipped: " << entry << std::endl;
                }
            }
        }
        
        

        std::getline(loadfrom,line);
    };

    std::cout << "Loaded " << world.numObj(true) << " visible meshes\n";

	// instantiate camera
	Camera camera = Camera();
	camera.setWorld(&world);

	camera.setPos(0, 0);
	camera.setPos(1, 0);
	camera.setPos(2, -4);
	camera.setForward(0, 0);
	camera.setForward(1, 0);
	camera.setForward(2, 1); 

    camera.setFov(FOV);

	for(int i = 0; i < HEIGHT * WIDTH; i++)
	{
		if(i % 3 == 0)
		{
			screen.frameBuffer[i] = 0xFFFF0000;
		}
	}

	screen.printBuffer();

	bool running = true;
    SDL_Event event;
    bool keys[SDL_SCANCODE_COUNT] = {};

	while (running)
	{
        // user input
		while (SDL_PollEvent(&event))
        {
            if (event.type == SDL_EVENT_QUIT)
            {
                running = false;
            }

            if (event.type == SDL_EVENT_KEY_DOWN && !event.key.repeat)
            {
                keys[event.key.scancode] = true;
            }

            if (event.type == SDL_EVENT_KEY_UP)
            {
                keys[event.key.scancode] = false;
            }
        }

        if (keys[SDL_SCANCODE_W])
        {
            camera.moveTowards(camera.getUp().add(camera.getPos()),0.15);
        }
        if (keys[SDL_SCANCODE_S])
        {
            camera.moveTowards(camera.getUp().add(camera.getPos()),-0.15);
        }

        if (keys[SDL_SCANCODE_ESCAPE])
        {
            running = false;
        }

        myMesh->setRotation(1,myMesh->getRotation().get(1) + 0.35);
        
        // render every frame
        screen.buildBuffer(camera);
        screen.printBuffer();

        SDL_Delay(7);
	}

	screen.explode();
	world.explode();

	return 0;
}