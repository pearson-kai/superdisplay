#include <iostream>
#include <cmath>
#include <numbers>

#include "Mesh.hpp"

Mesh::Mesh(std::string _name, Vec3 _pos, Vec3 _scale, Vec3 _rotation)
{
    name = _name;
    triangles = std::vector<Triangle>();
    pos = _pos;
    scale = _scale;
    rotation = _rotation;
    NUM_MESH++;
}

int Mesh::numTri()
{
    return triangles.size();
}

Triangle Mesh::getTri(int index)
{
    return triangles.at(index);
}

void Mesh::add(Triangle _tri)
{
    triangles.push_back(_tri);
    return;
}

Triangle Mesh::remove(int index)
{
    Triangle myTriangle = triangles.at(index);
    triangles.erase(triangles.begin() + index);
    return myTriangle;
}

std::string Mesh::getName()
{
    return name;
}

void Mesh::setName(std::string _name)
{
    name = _name;
}
    
Vec3 Mesh::getPos()
{
    return pos;
}

void Mesh::setPos(int index, float value)
{
    pos.set(index, value);
}

Vec3 Mesh::applyPos(Vec3 apply)
{
    apply.set(0, apply.get(0) + pos.get(0));
    apply.set(1, apply.get(1) + pos.get(1));
    apply.set(2, apply.get(2) + pos.get(2));
    return apply;
}

Vec3 Mesh::getScale()
{
    return scale;
}

void Mesh::setScale(int index, float value)
{
    scale.set(index, value);
}

void Mesh::setScale(Vec3 value)
{
    scale.set(0, value.get(0));
    scale.set(1, value.get(1));
    scale.set(2, value.get(2));
}

Vec3 Mesh::applyScale(Vec3 apply)
{
    apply.set(0, apply.get(0) * scale.get(0));
    apply.set(1, apply.get(1) * scale.get(1));
    apply.set(2, apply.get(2) * scale.get(2));
    return apply;
}

Vec3 Mesh::getRotation()
{
    return rotation;
}

void Mesh::setRotation(int index, float value)
{
    rotation.set(index,value);
}

void Mesh::normalizeRotation()
{
    for(int i = 0; i < 3; i++)
    {
        float angle = rotation.get(i);

        angle = fmod(angle, 360.0f);

        if(angle < 0)
        {
            angle += 360.0f;
        }

        rotation.set(i, angle);
    }
    
    return;
}

Vec3 Mesh::getCentroid()
{
    Vec3 sum(0,0,0);
    int count = 0;
    int size = triangles.size();
    for(int i = 0; i < size; i++) 
    {
        for(int j = 0; j < 3; j++)
        {
            sum = sum.add(triangles.at(i).get(j));
            count++;
        }
    }

    if (count == 0)
    {
        return Vec3(0,0,0);
    }

    return sum.divide((float)count);
}

Vec3 Mesh::applyRotation(Vec3 apply)
{
    float x = apply.get(0);
    float y = apply.get(1);
    float z = apply.get(2);

    float cx = std::cos(rotation.get(0) * std::acos(-1) / 180.0f);
    float sx = std::sin(rotation.get(0) * std::acos(-1) / 180.0f);
    float cy = std::cos(rotation.get(1) * std::acos(-1) / 180.0f);
    float sy = std::sin(rotation.get(1) * std::acos(-1) / 180.0f);
    float cz = std::cos(rotation.get(2) * std::acos(-1) / 180.0f);
    float sz = std::sin(rotation.get(2) * std::acos(-1) / 180.0f);

    float newX = x * (cy * cz) + y * (sx * sy * cz - cx * sz) + z * (cx * sy * cz + sx * sz);
    float newY = x * (cy * sz) + y * (sx * sy * sz + cx * cz) + z * (cx * sy * sz - sx * cz);
    float newZ = x * (-sy) + y * (sx * cy) + z * (cx * cy);

    apply.set(0, newX);
    apply.set(1, newY);
    apply.set(2, newZ);

    return apply;
}

Vec3 Mesh::localize(Vec3 apply)
{
    apply = applyScale(apply);
    apply = applyRotation(apply);
    apply = applyPos(apply);
    return apply;
}

Mesh* Mesh::meshMaker(fs::path _meshfile)
{
	std::ifstream in(_meshfile);
	
    if(!in)
    {
        std::cout << "Cannot open file: " << _meshfile;
        getch();
        return nullptr;
    }
    
	std::vector<Vec3> points;
	Mesh* mesh = new Mesh();
    std::string name = "";

    std::string line = "";
    float p[3];
    int t[3];
    Colour colour = Colour(rand() % 256, rand() % 256, rand() % 256, 255);

    while (std::getline(in,line))
	{
        
        switch(line[0])
        {
            case '#':
                continue;

            case 'v':
                line = line.substr(line.find(' ') + 1,line.size()); // remove the "v "

                colour = Colour(rand() % 256,rand() % 256,rand() % 256,255);

                p[0] = std::stof(line.substr(0,line.find(' ')));
                line = line.substr(line.find(' ') + 1, line.size());

                p[1] = std::stof(line.substr(0,line.find(' ')));
                line = line.substr(line.find(' ') + 1, line.size());

                p[2] = std::stof(line);

                points.push_back(Vec3(p[0],p[1],p[2],colour));
                break;
            
            case 'f':
                line = line.substr(line.find(' ') + 1,line.size()); // remove the "f "

                t[0] = std::stoi(line.substr(0,line.find(' ')));
                line = line.substr(line.find(' ') + 1, line.size());

                t[1] = std::stoi(line.substr(0,line.find(' ')));
                line = line.substr(line.find(' ') + 1, line.size());

                t[2] = std::stoi(line);

                mesh->add(Triangle(points[t[0] - 1], points[t[1] - 1], points[t[2] - 1]));
                break;
            case 'o':
                mesh->setName(line.substr(line.find(' ') + 1,line.size()));
        }
    }

	return mesh;
}







// LEGACY MESH MAKER
/*
Mesh* Mesh::meshMaker(fs::path _meshfile)
{
	std::ifstream in(_meshfile);
	if (!in)
    {
        std::cout << "Cannot open file: " << _meshfile;
        getch();
        return nullptr;
    }
    
	std::vector<Vec3> points;
	std::string line = "";
    std::getline(in, line);
    
    bool randColour = line == "random";
    if(randColour)
    {
        std::getline(in, line);
    }

    if(line == "end" || line == "skip")
    {
        return nullptr;
    }
    
    while (line != "triangles" && line != "end")
	{
        Colour colour;
		float p1 = std::stof(line.substr(0,line.find(' ')));
        line = line.substr(line.find(' ') + 1, line.size());

		float p2 = std::stof(line.substr(0,line.find(' ')));
        line = line.substr(line.find(' ') + 1, line.size());
        float p3 = 0;

		if(randColour)
        {
            p3 = std::stof(line);
            colour = Colour(rand() % 256,rand() % 256,rand() % 256,255);
        }
        else
        {

            p3 = std::stof(line.substr(0,line.find(' ')));
            line = line.substr(line.find(' ') + 1, line.size());

            uint8_t r = std::stoi(line.substr(0,line.find(' ')));
            line = line.substr(line.find(' ') + 1, line.size());

            uint8_t g = std::stoi(line.substr(0,line.find(' ')));
            line = line.substr(line.find(' ') + 1, line.size());
            
            uint8_t b = std::stoi(line.substr(0,line.find(' ')));
            line = line.substr(line.find(' ') + 1, line.size());

            colour = Colour(r,g,b,255);
        }

        points.push_back(Vec3(p1,p2,p3,colour));
        
        std::getline(in, line);

        if(line == "skip")
        {
            return nullptr;
        }
    }

    Mesh* mesh = new Mesh();

    std::getline(in, line);
	while (line != "end")
	{
        int t1 = std::stoi(line.substr(0,line.find(' ')));
        line = line.substr(line.find(' ') + 1, line.size());

		int t2 = std::stoi(line.substr(0,line.find(' ')));
        line = line.substr(line.find(' ') + 1, line.size());
		
        int t3 = std::stoi(line.substr(0,line.size()));

        mesh->add(Triangle(points[t1 - 1], points[t2 - 1], points[t3 - 1]));

        std::getline(in, line);
        
        if(line == "skip")
        {
            return nullptr;
        }
    }

    

	return mesh;
}*/