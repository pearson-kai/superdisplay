#include <cmath>
#include "Screen.hpp"

void print(std::string myString)
{
    std::cout << myString << std::endl;
}

Screen::Screen(std::string _name, int _width, int _height)
{
    name = _name;
    width = _width;
    height = _height;

    window = SDL_CreateWindow(_name.c_str(), _width, _height, SDL_WINDOW_RESIZABLE);
    if (!window)
    {
        std::cerr << "SDL_CreateWindow failed: " << SDL_GetError() << std::endl;
    }

    renderer = SDL_CreateRenderer(window, NULL);
    if (!renderer)
    {
        std::cerr << "SDL_CreateRenderer failed: " << SDL_GetError() << std::endl;
    }

    texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, _width, _height);
    if (!texture)
    {
        std::cerr << "SDL_CreateTexture failed: " << SDL_GetError() << std::endl;
    }

    resizeBuffer();
}

void Screen::setColour(Colour colour)
{
    SDL_SetRenderDrawColor(renderer, colour.get(0),colour.get(1),colour.get(2),colour.get(3));
}

void Screen::clearBuffer()
{
    std::fill(zBuffer.begin(), zBuffer.end(), -1);
    std::fill(frameBuffer.begin(),frameBuffer.end(),0xFF000000);
}

void Screen::resizeBuffer()
{
    zBuffer.resize(width * height);
    frameBuffer.resize(width * height);
    clearBuffer();
}








void Screen::buildBuffer(Camera camera)
{
    clearBuffer();

    World* world = camera.getWorld();
    if (!world)
    {
        //std::cout << "Screen::buildBuffer: camera has no world set\n";
        return;
    }

    Mesh* currentMesh = nullptr;

    int numMeshes = world->numObj(true);
    if (numMeshes == 0)
    {
        //std::cout << "Screen::buildBuffer: no visible meshes in world\n";
        return;
    }

    int numTriangles = 0;

    camera.updateRight();

    camera.normalizeForward();
    camera.normalizeUp();
    camera.normalizeRight();

    float rad = camera.getFov() * std::acos(-1) / 180.0f;
    float fval = DIST_CONST / std::tan(rad * 0.5f);
    
    for(int i = 0; i < numMeshes; i++)
    {
        currentMesh = world->getObj(true, i);
        numTriangles = currentMesh->numTri();

        for(int j = 0; j < numTriangles; j++)
        {
            Triangle currentTri = currentMesh->getTri(j);
            
            Vec3 p1 = currentMesh->localize(currentTri.get(0));
            Vec3 p2 = currentMesh->localize(currentTri.get(1));
            Vec3 p3 = currentMesh->localize(currentTri.get(2));

            p1 = p1.subtract(camera.getPos()).applyRotation(camera.getForward(), camera.getUp(), camera.getRight());
            p2 = p2.subtract(camera.getPos()).applyRotation(camera.getForward(), camera.getUp(), camera.getRight());
            p3 = p3.subtract(camera.getPos()).applyRotation(camera.getForward(), camera.getUp(), camera.getRight());

            // reject triangles that are behind the camera
            if (p1.get(2) <= 0 && p2.get(2) <= 0 && p3.get(2) <= 0)
            {
                continue;
            }

            p1 = camera.project(fval, p1);
            p2 = camera.project(fval, p2);
            p3 = camera.project(fval, p3);

            // map projection space (-1..1) to screen pixels (0..width/height)
            p1.set(0, p1.get(0) + width * 0.5f);
            p1.set(1, height * 0.5f - p1.get(1));
            p2.set(0, p2.get(0) + width * 0.5f);
            p2.set(1, height * 0.5f - p2.get(1));
            p3.set(0, p3.get(0) + width * 0.5f);
            p3.set(1, height * 0.5f - p3.get(1));

            rasterizer(p1,p2,p3);
        }
    }

}


/*

// culling
Vec3 normal = triangle.get(1).subtract(triangle.get(0)).cross(triangle.get(2).subtract(triangle.get(0)));
if(normal.get(2) <= 0)
{
    return;
}

*/

void Screen::rasterizer(Vec3& v0, Vec3& v1, Vec3& v2)
{
    float area = Vec3::edge(v0, v1, v2);
    float absArea = (area < 0 ? -area : area);
    if (absArea < 1e-4f)
    {
        // Triangle is effectively a point/line in screen space; draw a pixel at its centroid so it is visible.
        int cx = (int)std::round((v0.get(0) + v1.get(0) + v2.get(0)) / 3.0f);
        int cy = (int)std::round((v0.get(1) + v1.get(1) + v2.get(1)) / 3.0f);
        if (cx >= 0 && cx < width && cy >= 0 && cy < height)
        {
            frameBuffer[cy * width + cx] = 0xFFFF0000;
        }
        return;
    }

    // clamp bounding box to screen bounds
    int minX = std::max(0, (int)floor(std::min(v0.get(0), std::min(v1.get(0), v2.get(0)))));
    int maxX = std::min(width - 1, (int)ceil(std::max(v0.get(0), std::max(v1.get(0), v2.get(0)))));
    int minY = std::max(0, (int)floor(std::min(v0.get(1), std::min(v1.get(1), v2.get(1)))));
    int maxY = std::min(height - 1, (int)ceil(std::max(v0.get(1), std::max(v1.get(1), v2.get(1)))));


    for (int y = minY; y <= maxY; y++)
    {
        for (int x = minX; x <= maxX; x++)
        {
            Vec3 p(x + 0.5f, y + 0.5f, 0);

            float w0 = Vec3::edge(v1, v2, p);
            float w1 = Vec3::edge(v2, v0, p);
            float w2 = Vec3::edge(v0, v1, p);



            if ((w0 >= 0 && w1 >= 0 && w2 >= 0) || (w0 <= 0 && w1 <= 0 && w2 <= 0))
            {
                w0 /= area;
                w1 /= area;
                w2 /= area;

                float depth = w0 * v0.get(2) + w1 * v1.get(2) + w2 * v2.get(2);

                int index = (y * width) + x;
                if (zBuffer[index] == -1 || depth < zBuffer[index])
                {
                    zBuffer[index] = depth;

                    // https://www.desmos.com/calculator/ztnwk5v2nt
                    //int offset = (int) 100 * ((pow(3,(0.000000005f * depth - 8.55f))) / (pow(3,(0.000000005f * depth - 8.55f))) + 1) - 1;
                    int offset = 0;
                    if(offset < 0)
                    {
                        offset = 0;
                    }

                    uint8_t r = static_cast<uint8_t>(w0 * v0.getColour().get(0) + w1 * v1.getColour().get(0) + w2 * v2.getColour().get(0)) - offset;
                    uint8_t g = static_cast<uint8_t>(w0 * v0.getColour().get(1) + w1 * v1.getColour().get(1) + w2 * v2.getColour().get(1)) - offset;
                    uint8_t b = static_cast<uint8_t>(w0 * v0.getColour().get(2) + w1 * v1.getColour().get(2) + w2 * v2.getColour().get(2)) - offset;
                    frameBuffer[index] = Colour(r, g, b, 255).convert();
                }
            }
        }
    }
}


void Screen::printBuffer()
{
    // paste buffer to texture and upload to renderer
    SDL_RenderClear(renderer);

    if (!SDL_UpdateTexture(texture, nullptr, frameBuffer.data(), width * sizeof(uint32_t)))
    {
        std::cerr << "SDL_UpdateTexture failed: " << SDL_GetError() << std::endl;
        return;
    }

    if (!SDL_RenderTexture(renderer, texture, nullptr, nullptr))
    {
        std::cerr << "SDL_RenderTexture failed: " << SDL_GetError() << std::endl;
        return;
    }

    displayScene();
}





















void Screen::displayScene()
{
    SDL_RenderPresent(renderer);
}

void Screen::clearScene()
{
    SDL_RenderClear(renderer);

    return;
}

void Screen::coatColour(Colour colour)
{
    setColour(colour);
    SDL_RenderClear(renderer);
    SDL_RenderPresent(renderer);
    setColour(Colour(0,0,0,255));

    return;
}

void Screen::explode()
{
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_DestroyTexture(texture);

    texture = nullptr;
    renderer = nullptr;
    window = nullptr;
    
    return;
}