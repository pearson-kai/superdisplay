#include "World.hpp"

/*  
    Status Codes:
100 - changes successfully applied

200 - mesh does not exist in this world
201 - mesh already exists in this world (duplicate add)
202 - mesh has no polygons
203 - mesh has another problem (scale of 0,0,0)
300 - mesh passed is a nullptr  
*/

World::World()
{
    visible = std::vector<Mesh*>();
    hidden = std::vector<Mesh*>();
}

int World::checkProblems(Mesh* check)
{
    if(check == nullptr)
    {
        return 300;
    }

    if(check->numTri() == 0)
    {
        return 202;
    }

    Vec3 scale = check->getScale();
    if(scale.get(0) == 0 && scale.get(1) == 0 && scale.get(2) == 0)
    {
        return 203;
    }

    return 100;
}

int World::numObj(bool visibility)
{
    if(visibility)
    {
        return visible.size();
    }
    
    return hidden.size();
}

Mesh* World::getObj(bool visibility, int index)
{
    if(visibility)
    {
        return visible.at(index);
    }
    
    return hidden.at(index);
}

void World::setAllVisibility(bool visibility)
{
    int size = 0;
    if(visibility)
    {
        size = hidden.size();
    }
    else
    {
        size = visible.size();
    }

    for(int i = 0; i < size; i++)
    {
        if(visibility)
        {
            visible.push_back(hidden.at(0));
            hidden.erase(hidden.begin());
        }
        else
        {
            hidden.push_back(visible.at(0));
            visible.erase(visible.begin());
        }
    }
}

int World::setVisibility(bool visibility, Mesh* obj)
{
    int size = 0;
    if(visibility)
    {
        size = hidden.size();
    }
    else
    {
        size = visible.size();
    }

    // check to find in old visible pile
    for(int i = 0; i < size; i++)
    {
        if(visibility)
        {
            if(hidden.at(i) == obj)
            {
                visible.push_back(obj);
                hidden.erase(hidden.begin() + i);
                return 100;
            }
        }
        else
        {
            if(visible.at(i) == obj)
            {
                hidden.push_back(obj);
                visible.erase(visible.begin() + i);
                return 100;
            }
        }
    }
    
    // check to find in new visible pile
    if(visibility)
    {
        size = visible.size();
    }
    else
    {
        size = hidden.size();
    }

    for(int i = 0; i < size; i++)
    {
        if(visibility)
        {
            if(hidden.at(i) == obj)
            {
                visible.push_back(obj);
                hidden.erase(hidden.begin() + i);
                return 100;
            }
        }
        else
        {
            if(visible.at(i) == obj)
            {
                hidden.push_back(obj);
                visible.erase(visible.begin() + i);
                return 100;
            }
        }
    }

    // mesh doesn't exist in the world
    return 200;
}

int World::add(bool visibility, Mesh* obj)
{
    int hiddensize = hidden.size();
    for(int i = 0; i < hiddensize; i++)
    {
        if(hidden.at(i) == obj)
        {
            return 201;
        }
    }

    int visiblesize = visible.size();
    for(int i = 0; i < visiblesize; i++)
    {
        if(visible.at(i) == obj)
        {
            return 201;
        }
    }


    if(visibility)
    {
        visible.push_back(obj);
    }
    else
    {
        hidden.push_back(obj);
    }

    return 100;
}

int World::remove(bool visibility, int index)
{
    return 100;
} // deletes a mesh of a visibility at an index

int World::remove(Mesh* obj)
{
    int size = visible.size();
    for(int i = 0; i < size; i++)
    {
        if(visible.at(i) == obj)
        {
            visible.erase(visible.begin() + i);
            return 100;
        }
    }

    size = hidden.size();
    for(int i = 0; i < size; i++)
    {
        if(visible.at(i) == obj)
        {
            visible.erase(visible.begin() + i);
            return 100;
        }
    }

    return 200;
} // deletes a specific mesh

int World::sweep()
{
    int size = visible.size();
    for(int i = 0; i < size; i++)
    {
        for(int j = 0; j < size; j++)
        {
            if(i != j && visible.at(i) == visible.at(j))
            {
                delete visible.at(j);
                visible.erase(visible.begin() + j);
                j--;
            }
        }
    }

    size = hidden.size();
    for(int i = 0; i < size; i++)
    {
        for(int j = 0; j < size; j++)
        {
            if(i != j && hidden.at(i) == hidden.at(j))
            {
                delete hidden.at(j);
                hidden.erase(hidden.begin() + j);
                j--;
            }
        }
    }

    return 100;
}

// deletes all meshes safely
void World::explode()
{
    for(int i = visible.size() - 1; 0 <= i; i--)
    {
        delete visible.at(i);
        visible.erase(visible.begin() + i);
    }

    for(int i = hidden.size() - 1; 0 <= i; i--)
    {
        delete hidden.at(0);
        hidden.erase(hidden.begin() + i);
    }
}